
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

function h($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

$search = trim($_GET['search'] ?? '');

if ($search !== '') {
    $stmt = $conn->prepare(
        "SELECT * FROM patients
         WHERE patient_name LIKE ? OR contact_number LIKE ?
         ORDER BY id DESC"
    );
    $keyword = "%".$search."%";
    $stmt->bind_param("ss", $keyword, $keyword);
    $stmt->execute();
    $patients = $stmt->get_result();
} else {
    $patients = $conn->query("SELECT * FROM patients ORDER BY id DESC");
}

if (!$patients) {
    die("Database error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Patient Records</title>
<style>
* { box-sizing:border-box; }
body { margin:0; font-family:Arial,sans-serif; background:#f1f5f9; color:#243447; }
.sidebar { position:fixed; width:230px; height:100vh; background:#123c55; color:white; padding:25px 18px; }
.sidebar h2 { text-align:center; margin-bottom:35px; }
.sidebar a { display:block; color:white; text-decoration:none; padding:13px; border-radius:7px; margin-bottom:10px; }
.sidebar a:hover, .sidebar a.active { background:#245b78; }
.main { margin-left:230px; padding:30px; }
.panel { background:white; padding:22px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,.06); margin-top:20px; overflow-x:auto; }
.btn { display:inline-block; background:#087e8b; color:white; padding:11px 16px; border:0; border-radius:6px; text-decoration:none; cursor:pointer; }
input { padding:11px; border:1px solid #cbd5e1; border-radius:6px; }
table { width:100%; border-collapse:collapse; min-width:700px; margin-top:15px; }
th,td { padding:13px; text-align:left; border-bottom:1px solid #e2e8f0; }
th { background:#eaf1f5; }
.clickable-row { cursor:pointer; }
.clickable-row:hover { background:#e0f2f1; }
.message { padding:12px; background:#dcfce7; color:#166534; border-radius:6px; margin:15px 0; }
@media(max-width:750px) {
    .sidebar { position:relative; width:100%; height:auto; }
    .main { margin-left:0; padding:18px; }
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>✚ CLINIC</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="patient_records.php" class="active">Patient Records</a>
    <a href="add_patient.php">Add Patient</a>
    <a href="index.php">Logout</a>
</div>

<div class="main">
    <h1>Patient Records</h1>
    <p>Click a patient to view their complete information.</p>

    <?php if (isset($_GET['added'])): ?>
        <div class="message">Patient successfully added!</div>
    <?php endif; ?>

    <div class="panel">
        <a href="add_patient.php" class="btn">+ Add New Patient</a>

        <form method="GET" action="patient_records.php" style="margin-top:20px;">
            <input type="text" name="search"
                   placeholder="Search patient name or contact number"
                   value="<?= h($search) ?>">
            <button type="submit" class="btn">Search</button>
            <a href="patient_records.php" class="btn">Reset</a>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Contact Number</th>
                    <th>Diagnosis</th>
                    <th>Visit Date</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($patients->num_rows > 0): ?>
                <?php while ($row = $patients->fetch_assoc()): ?>
                    <tr class="clickable-row"
                        onclick="window.location.href='patient_view.php?id=<?= (int)$row['id'] ?>'">
                        <td><?= h($row['id']) ?></td>
                        <td><?= h($row['patient_name']) ?></td>
                        <td><?= h($row['age']) ?></td>
                        <td><?= h($row['gender']) ?></td>
                        <td><?= h($row['contact_number']) ?></td>
                        <td><?= h($row['diagnosis']) ?></td>
                        <td><?= h($row['visit_date']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7">No patient records found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
