
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = "";

function h($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_patient'])) {
    $patient_name = trim($_POST['patient_name'] ?? '');
    $age = (int)($_POST['age'] ?? 0);
    $gender = trim($_POST['gender'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $contact_number = trim($_POST['contact_number'] ?? '');
    $diagnosis = trim($_POST['diagnosis'] ?? '');
    $treatment = trim($_POST['treatment'] ?? '');
    $visit_date = trim($_POST['visit_date'] ?? '');

    if ($patient_name === '' || $age < 1 || $gender === '' ||
        $address === '' || $contact_number === '' ||
        $diagnosis === '' || $treatment === '' || $visit_date === '') {
        $error = "Please complete all patient information.";
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO patients
            (patient_name, age, gender, address, contact_number,
             diagnosis, treatment, visit_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );

        if (!$stmt) {
            $error = "Database error: " . $conn->error;
        } else {
            $stmt->bind_param(
                "sissssss",
                $patient_name,
                $age,
                $gender,
                $address,
                $contact_number,
                $diagnosis,
                $treatment,
                $visit_date
            );

            if ($stmt->execute()) {
                $stmt->close();
                header("Location: patient_records.php?added=1");
                exit();
            } else {
                $error = "Unable to save patient: " . $stmt->error;
                $stmt->close();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Patient</title>
<style>
* { box-sizing:border-box; }
body { margin:0; font-family:Arial,sans-serif; background:#f1f5f9; color:#243447; }
.sidebar { position:fixed; width:230px; height:100vh; background:#123c55; color:white; padding:25px 18px; }
.sidebar h2 { text-align:center; margin-bottom:35px; }
.sidebar a { display:block; color:white; text-decoration:none; padding:13px; border-radius:7px; margin-bottom:10px; }
.sidebar a:hover, .sidebar a.active { background:#245b78; }
.main { margin-left:230px; padding:30px; }
.panel { background:white; padding:25px; border-radius:10px; max-width:850px; box-shadow:0 2px 8px rgba(0,0,0,.06); margin-top:20px; }
.form-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:15px; }
.form-group { margin-bottom:12px; }
.full { grid-column:1/-1; }
input,select,textarea { width:100%; padding:11px; border:1px solid #cbd5e1; border-radius:6px; margin-top:7px; font-size:14px; }
textarea { resize:vertical; }
.btn { display:inline-block; background:#087e8b; color:white; padding:11px 17px; border:0; border-radius:6px; text-decoration:none; cursor:pointer; }
.error { background:#fee2e2; color:#991b1b; padding:12px; border-radius:6px; margin-bottom:15px; }
@media(max-width:750px) {
    .sidebar { position:relative; width:100%; height:auto; }
    .main { margin-left:0; padding:18px; }
    .form-grid { grid-template-columns:1fr; }
    .full { grid-column:auto; }
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>✚ CLINIC</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="patient_records.php">Patient Records</a>
    <a href="add_patient.php" class="active">Add Patient</a>
    <a href="index.php">Logout</a>
</div>

<div class="main">
    <h1>Add New Patient</h1>
    <p>Enter the patient's information below.</p>

    <div class="panel">
        <?php if ($error): ?>
            <div class="error"><?= h($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="add_patient.php">
            <div class="form-grid">

                <div class="form-group">
                    <label>Patient Name</label>
                    <input type="text" name="patient_name" required>
                </div>

                <div class="form-group">
                    <label>Age</label>
                    <input type="number" name="age" min="1" required>
                </div>

                <div class="form-group">
                    <label>Gender</label>
                    <select name="gender" required>
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Contact Number</label>
                    <input type="text" name="contact_number" required>
                </div>

                <div class="form-group full">
                    <label>Address</label>
                    <textarea name="address" rows="3" required></textarea>
                </div>

                <div class="form-group">
                    <label>Diagnosis</label>
                    <input type="text" name="diagnosis" required>
                </div>

                <div class="form-group">
                    <label>Treatment</label>
                    <input type="text" name="treatment" required>
                </div>

                <div class="form-group">
                    <label>Visit Date</label>
                    <input type="date" name="visit_date" required>
                </div>

            </div>

            <br>
            <button type="submit" name="add_patient" class="btn">Save Patient</button>
            <a href="patient_records.php" class="btn">Cancel</a>
        </form>
    </div>
</div>

</body>
</html>
