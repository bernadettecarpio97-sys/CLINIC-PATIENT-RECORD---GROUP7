
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

function h($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

$patientId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$patientId || $patientId < 1) {
    die("Invalid patient ID.");
}

$stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->bind_param("i", $patientId);
$stmt->execute();
$result = $stmt->get_result();
$patient = $result->fetch_assoc();
$stmt->close();

if (!$patient) {
    die("Patient record not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Patient Information</title>
<style>
* { box-sizing:border-box; }
body { margin:0; font-family:Arial,sans-serif; background:#f1f5f9; color:#243447; }
.sidebar { position:fixed; width:230px; height:100vh; background:#123c55; color:white; padding:25px 18px; }
.sidebar h2 { text-align:center; margin-bottom:35px; }
.sidebar a { display:block; color:white; text-decoration:none; padding:13px; border-radius:7px; margin-bottom:10px; }
.sidebar a:hover { background:#245b78; }
.main { margin-left:230px; padding:30px; }
.panel { background:white; padding:25px; border-radius:10px; max-width:900px; margin-top:20px; box-shadow:0 2px 8px rgba(0,0,0,.06); }
.details { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:15px; }
.detail { background:#f8fafc; padding:15px; border-radius:7px; overflow-wrap:anywhere; }
.detail strong { display:block; color:#64748b; margin-bottom:7px; }
.btn { display:inline-block; background:#087e8b; color:white; padding:11px 17px; border-radius:6px; text-decoration:none; margin-top:20px; }
@media(max-width:750px) {
    .sidebar { position:relative; width:100%; height:auto; }
    .main { margin-left:0; padding:18px; }
    .details { grid-template-columns:1fr; }
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>✚ CLINIC</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="patient_records.php">Patient Records</a>
    <a href="add_patient.php">Add Patient</a>
    <a href="index.php">Logout</a>
</div>

<div class="main">
    <h1>Patient Information</h1>

    <div class="panel">
        <div class="details">
            <div class="detail"><strong>Patient ID</strong><?= h($patient['id']) ?></div>
            <div class="detail"><strong>Patient Name</strong><?= h($patient['patient_name']) ?></div>
            <div class="detail"><strong>Age</strong><?= h($patient['age']) ?></div>
            <div class="detail"><strong>Gender</strong><?= h($patient['gender']) ?></div>
            <div class="detail"><strong>Address</strong><?= h($patient['address']) ?></div>
            <div class="detail"><strong>Contact Number</strong><?= h($patient['contact_number']) ?></div>
            <div class="detail"><strong>Diagnosis</strong><?= h($patient['diagnosis']) ?></div>
            <div class="detail"><strong>Treatment</strong><?= h($patient['treatment']) ?></div>
            <div class="detail"><strong>Visit Date</strong><?= h($patient['visit_date']) ?></div>
            <div class="detail"><strong>Created At</strong><?= h($patient['created_at']) ?></div>
        </div>

        <a href="patient_records.php" class="btn">← Back to Patient Records</a>
    </div>
</div>

</body>
</html>
