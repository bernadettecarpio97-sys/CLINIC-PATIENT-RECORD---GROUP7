
<?php
require_once "config.php";

function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

$mess = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $uname = trim($_POST['uname'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    // Check username
    if ($uname === '') {
        $errors[] = "Please enter your username.";
    }

    // Check password
    if ($password === '') {
        $errors[] = "Please enter your password.";
    }

    // Check if passwords match
    if ($password !== $password2) {
        $errors[] = "Passwords do not match.";
    }

    if (empty($errors)) {

        // Check if username already exists
        $check = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $check->bind_param('s', $uname);
        $check->execute();

        $result = $check->get_result();

        if ($result->num_rows > 0) {

            $errors[] = "Username already exists. Please choose another.";

        } else {

            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // ENUM values
            $status = "pending";
            $role = "users";

            // Insert account
            $stmt = $conn->prepare(
                "INSERT INTO users (username, password, status, role)
                 VALUES (?, ?, ?, ?)"
            );

            $stmt->bind_param('ssss', $uname, $hashedPassword, $status, $role);

            if ($stmt->execute()) {
                $mess[] = "Registered successfully. Please wait for the admin approval of your account.";
            } else {
                $errors[] = "Something went wrong. Please try again in a minute.";
            }

            $stmt->close();
        }

        $check->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #0f172a, #1e40af);
        }

        .register-container {
            background: white;
            width: 420px;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 35px rgba(0,0,0,0.25);
        }

        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .register-header h1 {
            color: #1e40af;
            font-size: 27px;
            margin-bottom: 12px;
        }

        .register-header h2 {
            color: #333;
            font-size: 20px;
            font-weight: normal;
        }

        .register-header p {
            color: #777;
            font-size: 13px;
            margin-top: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 13px;
            border: 1px solid #ccc;
            border-radius: 7px;
            outline: none;
            font-size: 14px;
        }

        .form-group input:focus {
            border-color: #2563eb;
            box-shadow: 0 0 5px rgba(37,99,235,0.3);
        }

        .register-button {
            width: 100%;
            padding: 13px;
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 7px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .register-button:hover {
            background: #1e40af;
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            color: #555;
            font-size: 14px;
        }

        .login-link a {
            color: #2563eb;
            text-decoration: none;
            font-weight: bold;
        }

        .login-link a:hover {
            text-decoration: underline;
        }

        .error-message {
            background: #fee2e2;
            color: #b91c1c;
            padding: 12px;
            border-radius: 7px;
            margin-bottom: 15px;
            font-size: 13px;
        }

        .success-message {
            background: #dcfce7;
            color: #166534;
            padding: 12px;
            border-radius: 7px;
            margin-bottom: 15px;
            font-size: 13px;
        }

        @media (max-width: 480px) {
            .register-container {
                width: 90%;
                padding: 30px 22px;
            }
        }
    </style>
</head>

<body>

    <div class="register-container">

        <div class="register-header">
            <h1>Clinic Patient Record</h1>
            <h2>Create Your Account</h2>
            <p>Register to access the management system</p>
        </div>

        <?php foreach ($errors as $e): ?>
            <div class="error-message">
                <?= h($e) ?>
            </div>
        <?php endforeach; ?>

        <?php foreach ($mess as $m): ?>
            <div class="success-message">
                <?= h($m) ?>
            </div>
        <?php endforeach; ?>

        <form action="" method="POST">

            <div class="form-group">
                <label for="uname">Username</label>
                <input
                    type="text"
                    id="uname"
                    name="uname"
                    placeholder="Enter username"
                    required
                    autofocus
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter password"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password2">Re-enter Password</label>
                <input
                    type="password"
                    id="password2"
                    name="password2"
                    placeholder="Re-enter password"
                    required
                >
            </div>

            <button type="submit" class="register-button">
                Create Account
            </button>

        </form>

        <div class="login-link">
            <p>Already have an account? <a href="index.php">Sign In</a></p>
        </div>

    </div>

</body>
</html>
