
<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$totalResult = $conn->query("SELECT COUNT(*) AS total FROM patients");
$totalPatients = $totalResult ? $totalResult->fetch_assoc()['total'] : 0;

$today = date("Y-m-d");
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM patients WHERE visit_date = ?");
$stmt->bind_param("s", $today);
$stmt->execute();
$todayVisits = $stmt->get_result()->fetch_assoc()['total'];
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Clinic Dashboard</title>
<style>
* { box-sizing: border-box; }
body { margin:0; font-family:Arial,sans-serif; background:#f1f5f9; color:#243447; }
.sidebar { position:fixed; width:230px; height:100vh; background:#123c55; color:white; padding:25px 18px; }
.sidebar h2 { text-align:center; margin-bottom:35px; }
.sidebar a { display:block; color:white; text-decoration:none; padding:13px; border-radius:7px; margin-bottom:10px; }
.sidebar a:hover, .sidebar a.active { background:#245b78; }
.main { margin-left:230px; padding:30px; }
.cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:20px; margin-top:25px; }
.card { background:white; padding:25px; border-radius:10px; box-shadow:0 2px 8px rgba(0,0,0,.06); }
.card h3 { color:#64748b; margin-top:0; }
.card h1 { font-size:32px; margin-bottom:0; }
@media(max-width:750px) {
    .sidebar { position:relative; width:100%; height:auto; }
    .main { margin-left:0; padding:18px; }
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>✚ CLINIC</h2>
    <a href="dashboard.php" class="active">Dashboard</a>
    <a href="patient_records.php">Patient Records</a>
    <a href="add_patient.php">Add Patient</a>
    <a href="index.php">Logout</a>
</div>

<div class="main">
    <h1>Dashboard</h1>
    <p>Welcome to the Clinic Management System.</p>

    <div class="cards">
        <div class="card">
            <h3>Total Patients</h3>
            <h1><?= (int)$totalPatients ?></h1>
        </div>

        <div class="card">
            <h3>Today's Visits</h3>
            <h1><?= (int)$todayVisits ?></h1>
        </div>
    </div>
</div>

</body>
</html>
