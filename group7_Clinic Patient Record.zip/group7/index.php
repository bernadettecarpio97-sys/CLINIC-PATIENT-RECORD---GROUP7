
<?php
require_once "config.php";

function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $uname = trim($_POST['uname'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($uname === '' || $password === '') {
        $errors[] = "Please enter your username and password.";
    } else {

        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");

        if (!$stmt) {
            die("Database Error: " . h($conn->error));
        }

        $stmt->bind_param('s', $uname);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $stmt->close();

        if ($user && password_verify($password, $user['password'])) {

            if ($user['status'] !== "approved") {

                $errors[] = "Your account has not been approved by the admin.";

            } else {

                session_regenerate_id(true);

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                // Redirect to your actual dashboard filename
                header("Location: dashboard.php");
                exit();

            }

        } else {

            $errors[] = "Invalid username or password.";

        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #0f172a, #1e40af);
        }

        .login-container {
            background: white;
            width: 400px;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 35px rgba(0,0,0,0.25);
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-header h1 {
            color: #1e40af;
            font-size: 28px;
            margin-bottom: 10px;
        }

        .login-header h2 {
            color: #333;
            font-size: 20px;
            font-weight: normal;
        }

        .login-header p {
            color: #777;
            font-size: 13px;
            margin-top: 10px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 13px;
            border: 1px solid #ccc;
            border-radius: 7px;
            outline: none;
            font-size: 14px;
            transition: 0.3s;
        }

        .form-group input:focus {
            border-color: #2563eb;
            box-shadow: 0 0 5px rgba(37,99,235,0.3);
        }

        .login-button {
            width: 100%;
            padding: 13px;
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 7px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .login-button:hover {
            background: #1e40af;
        }

        .register-link {
            text-align: center;
            margin-top: 25px;
            font-size: 14px;
            color: #555;
        }

        .register-link a {
            color: #2563eb;
            text-decoration: none;
            font-weight: bold;
        }

        .register-link a:hover {
            text-decoration: underline;
        }

        .error-message {
            background: #fee2e2;
            color: #b91c1c;
            padding: 12px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }

        @media (max-width: 480px) {
            .login-container {
                width: 90%;
                padding: 30px 22px;
            }
        }
    </style>
</head>

<body>

    <div class="login-container">

        <div class="login-header">
            <h1>Clinic Patient Record</h1>
            <h2>Welcome Back!</h2>
            <p>Sign in to access your account</p>
        </div>

        <?php foreach ($errors as $e): ?>
            <div class="error-message">
                <?= h($e) ?>
            </div>
        <?php endforeach; ?>

        <form action="" method="post">

            <div class="form-group">
                <label for="uname">Username</label>
                <input
                    type="text"
                    id="uname"
                    name="uname"
                    placeholder="Enter your username"
                    required
                    autofocus
                >
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >
            </div>

            <button type="submit" class="login-button">
                Sign In
            </button>

        </form>

        <div class="register-link">
            <p>No Account? <a href="register.php">Register Here</a></p>
        </div>

    </div>

</body>
</html>
